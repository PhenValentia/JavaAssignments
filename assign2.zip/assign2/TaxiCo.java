//Importing ArrayLists and their Functions
import java.util.ArrayList;
/**
 * Keep track of multiple taxis.
 * @author your-name
 * @version your-date
 */
public class TaxiCo
{
    public ArrayList<Taxi> taxis;
    /**
     * Create a TaxiCo object.
     */
    public TaxiCo()
    {
        taxis = new ArrayList<>();
    }

    /**
     * Add a new taxi.
     * @param taxi The taxi.
     */
    public void addTaxi(Taxi taxi)
    {
        taxis.add(taxi);
    }

    /**
     * Get the number of taxis.
     * @return the number of taxis.
     */
    public int getNumberOfTaxis()
    {
        return taxis.size();
    }

    /**
     * Get the number of taxis in the given area.
     * @param area The area of the taxis.
     * @return the number of taxis in the given area.
     */
    public int getNumberOfTaxis(int area)
    {
        int numTax = 0;
        for (Taxi taxi: taxis)
        {
            if (taxi.getArea() == area){
                numTax++;
            }
        }
        return numTax;
    }

    /**
     * List all of the taxis, one per line.
     */
    public void list()
    {
        for (Taxi taxi: taxis)
        {
            System.out.println(taxi.getDetails());
        }
    }

    /**
     * Remove the taxi with the given id.
     * @param day The id of the taxi to be removed.
     * @return true if a taxi was removed, false otherwise.
     */
    public boolean removeTaxi(int id)
    {
        boolean testNum = false;
        int index = 0;
        Taxi testTax = null;
        while (!testNum && index < taxis.size())
        {
            testTax = taxis.get(index);
            if(testTax.getID() == id){
                testNum = taxis.remove(testTax);
            }
            index++;
        } 
        return testNum;
    }

    /**
     * Set the status of the taxi whose ID is given.
     * @param id The taxi's ID.
     * @param area The taxi's new area.
     * @param free Whether it is now free or not.
     */
    public void setStatus(int id, int area, boolean free)
    {
        boolean testNum = false;
        int index = 0;
        while(!testNum && index < taxis.size())
        {
            if(taxis.get(index).getID() == id)
            {
                if (free == true)
                {
                    taxis.get(index).setFree();
                }
                else 
                {
                    taxis.get(index).setOccupied();
                }
                taxis.get(index).moveTo(area);
                testNum = true;
            }
            index++;
        }  
    }

    /**
     * Find the nearest free taxi to the given area.
     * Distance is measured by the absolute value of the
     * difference between two areas.
     * For instance, the distance between areas 1 and 5 is 4,
     * and the distance between areas 6 and 4 is 2.
     * If more than one taxi is free and nearest to the given
     * area then the one with the lowest ID must be returned.
     * @param area Look for the taxi nearest to this area.
     * @return the nearest taxi, or null if there are no free taxis.
     */
    public Taxi findNearestFree(int area)
    {
        int lowAr = Integer.MAX_VALUE;
        Taxi nearTax = null;
        int testDist;
        int testID = 0;
        for (Taxi taxi: taxis)
        {
            if(taxi.isFree() == true)
            {
                testDist = Math.abs(area-taxi.getArea());
                if (testDist == lowAr && testID > taxi.getID())
                {
                    testID = taxi.getID();
                    nearTax = taxi;
                }
                if (testDist < lowAr)
                {
                    lowAr = testDist;
                    nearTax = taxi;
                    testID = taxi.getID();
                }
            }
        }      
        return nearTax;
    }
}
