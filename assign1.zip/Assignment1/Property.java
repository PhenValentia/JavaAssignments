
public class Property
{
    // The address of the house being sold.
    // It is defined as a String variable.
    private String address;
    // The highest offer for the house that someone has made for the house.
    // It is defined as an integer variable.
    private int highestOffer;
    // The reserve price of the house being sold.
    // It is defined as an integer variable.
    private int reservePrice;

    /** Constructor used to define variables.
     * It takes the house address and reserve price.
     * This is to set the starting value of previously defined variables.
     * 
     */ 
    public Property(int houseReservePrice,String houseAddress)
    {
        // Address being set upon construction of the object
        address = houseAddress;
        // Highest offer being given the beginning value of 0
        highestOffer = 0;
        /** Reserve price being set upon construction of the object.
         *  Entered value will become reserve price if greater or equal to 50000.
         *  If less than 50000, value will be set to 50000 and an error message will be displayed.
         *  The error message displayed is for ease of use.
         */ 
        if(houseReservePrice >= 50000)
        {
            reservePrice = houseReservePrice;
        }   
        else
        {
            System.out.println("Reserve Price must be greater than or equal to 50000 and so has been set to 50000");   
            reservePrice = 50000;
        }

    }

    /** This accessor method returns the current highest offer.
     */
    public int getHighestOffer()
    {
        return highestOffer;        
    }

    /** This accessor method returns the current address of the house on offer.
     */
    public String getHouseAddress()
    {
        return address;
    }

    /** A mutator method used to set the address to a new address by the user.
     */
    public void changeAddress(String newAddress)
    {
        address = newAddress;
    }

    /** A method used to make an offer but only accepts it if it is the highest offer.
     *  If the offer is higher than the current offer, the offer is accepted.
     *  This is accompanied with a printed message to say the offer
     *  as well as it having been accepted.
     *  If the offer is smaller than or equal to the highest offer, it remains the same.
     *  An error message will be printed and both the highest offer and the
     *  offer entered will be printed.
     */ 
    public void makeOffer(int offer)
    {
        if(offer > highestOffer)
        {
            highestOffer = offer;
            System.out.println("Offer Accepted.");
            System.out.println("Your offer of '"+highestOffer + "' is now the highest current offer.");
        }
        else
        {
            System.out.println("Offer Rejected.");
            System.out.println("Reason: Higher offer has been made.");
            System.out.println("Highest current offer: " + highestOffer);
            System.out.println("Your offer: " + offer);
        }

    }    

    /** A mutator method designed to change the reserve price to a new value set by the user.
     * For the following method, no lines are printed.
     * If value is not >= 50000, reserveValue should not change.
     */
    public void changeReserve(int newReserve)
    {
        if(newReserve >= 50000)
        {
            reservePrice = newReserve;
        }
    }

    /** This method prints out the details of the house on offer.
     * It prints the address, reserve price and the highest current offer. 
     * If the highest offer is below the reserve price, a message will be printed notifying the user.
     */
    public void printDetails()
    {
        if(highestOffer >= reservePrice)
        {
            System.out.println("The current offer for "+address+" is "+highestOffer+".");
        }
        else 
        {
            System.out.println("The current offer for "+address+" is "+highestOffer+".");
            System.out.println("The reserve has not been met.");

        }
    }

}